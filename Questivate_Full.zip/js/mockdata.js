const users = {
  students: [
    { email: "s1@school.org", name: "Student One" },
    { email: "s2@school.org", name: "Student Two" }
  ],
  teachers: [
    { email: "t1@school.org", name: "Teacher A" }
  ],
  admins: [
    { email: "admin@questivate.org", name: "Admin" }
  ]
};